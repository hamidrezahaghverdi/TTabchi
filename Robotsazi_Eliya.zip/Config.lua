do
local B = {
SudoID = "353893098",
Channel = "@Tm_RoYaL",
		}
return B
end